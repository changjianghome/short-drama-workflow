# Mac 本地语音服务部署与恢复指南

本服务为局域网内的 Agent 提供语音播报功能，使用 macOS 系统自带的语音合成引擎（Neural 声音）。本文件夹已内置服务端脚本 `server.py`。

---

## 1. 快速部署步骤

### 步骤 A：新建并复制脚本到本地持久目录
为了避免脚本因系统临时目录清理而失效，建议将其放置在用户根目录下：
1. 在 Mac 上创建目录：
   ```bash
   mkdir -p ~/say_server
   ```
2. 将同目录下的 `server.py` 复制过去：
   ```bash
   cp server.py ~/say_server/server.py
   ```
3. 赋予执行权限：
   ```bash
   chmod +x ~/say_server/server.py
   ```

### 步骤 B：配置开机自启 (macOS LaunchAgent)
1. 创建或编辑配置文件 `~/Library/LaunchAgents/com.user.sayserver.plist`：
   ```bash
   nano ~/Library/LaunchAgents/com.user.sayserver.plist
   ```
2. 写入以下 XML 配置内容（注意把 `/Users/wuwu` 替换为目标机器的实际用户名）：
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
   <plist version="1.0">
   <dict>
       <key>Label</key>
       <string>com.user.sayserver</string>
       <key>ProgramArguments</key>
       <array>
           <string>/usr/bin/python3</string>
           <string>/Users/wuwu/say_server/server.py</string>
       </array>
       <key>RunAtLoad</key>
       <true/>
       <key>KeepAlive</key>
       <true/>
       <key>StandardOutPath</key>
       <string>/Users/wuwu/say_server/server.log</string>
       <key>StandardErrorPath</key>
       <string>/Users/wuwu/say_server/server.log</string>
   </dict>
   </plist>
   ```

### 步骤 C：加载并启动服务
在终端运行以下命令启用服务：
```bash
# 卸载旧配置（若存在）
launchctl unload ~/Library/LaunchAgents/com.user.sayserver.plist

# 重新加载并启动
launchctl load ~/Library/LaunchAgents/com.user.sayserver.plist
```

---

## 2. 服务管理与调试命令
- **启动/加载服务**：`launchctl load ~/Library/LaunchAgents/com.user.sayserver.plist`
- **停止/卸载服务**：`launchctl unload ~/Library/LaunchAgents/com.user.sayserver.plist`
- **查看运行日志**：`cat ~/say_server/server.log`
- **测试接口**：
  ```bash
  curl -G -s --data-urlencode "text=测试语音播放" "http://<MAC_SAY_BACKUP_IP>:12345/say"
  ```

---

## 3. 附：服务端 Python 脚本源码 (`server.py`)
如果你没有拿到 `server.py` 文件，可以直接复制以下代码并保存为 `server.py`：

```python
#!/usr/bin/env python3
import json
import subprocess
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

class MultiServiceHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # http.server 默认使用 latin-1 解码 url。我们需要还原为字节流并用 utf-8 正确解码，以支持中文
        raw_path = self.path.encode('latin-1')
        decoded_path = urllib.parse.unquote_to_bytes(raw_path).decode('utf-8', errors='replace')

        parsed_url = urllib.parse.urlparse(decoded_path)
        path = parsed_url.path
        query_params = urllib.parse.parse_qs(parsed_url.query)

        # 路由分发 (只处理 /say，其他路由返回 404，为以后扩展做准备)
        if path == '/say':
            self.handle_say(query_params)
        else:
            self.handle_not_found(path)

    def handle_say(self, params):
        text = params.get('text', [''])[0]
        voice = params.get('voice', ['Lili'])[0]  # 默认使用 macOS 更自然的中文女声 Lili (如 Lili, Siri, Yuting, Tingting 等)

        if not text:
            self.send_json_response(400, {
                "status": "error",
                "message": "Missing 'text' parameter. Usage: /say?text=内容"
            })
            return

        try:
            # 异步调用 Mac 的 say 命令，避免播放长文本时阻塞 HTTP 响应
            subprocess.Popen(['say', '-v', voice, text])
            self.send_json_response(200, {
                "status": "success",
                "message": f"Successfully playing text: '{text}' using voice '{voice}'"
            })
        except Exception as e:
            self.send_json_response(500, {
                "status": "error",
                "message": f"Failed to execute say command: {str(e)}"
            })

    def handle_not_found(self, path):
        # 404 路由处理，便于后续在 12345 端口扩展其他路由
        self.send_json_response(404, {
            "status": "error",
            "message": f"Route '{path}' not found on this server. Did you mean /say?"
        })

    def send_json_response(self, status_code, data):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        # 允许跨域请求 (CORS)，方便其他网页或智能家居设备直接调用
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.wfile.write(response_bytes)

if __name__ == '__main__':
    PORT = 12345
    server = HTTPServer(('0.0.0.0', PORT), MultiServiceHandler)
    print(f"HTTP Server started on port {PORT}. Accessible within LAN.")
    print(f"Speech Endpoint: http://<MAC_SAY_BACKUP_IP>:{PORT}/say?text=hello")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server.")
```
