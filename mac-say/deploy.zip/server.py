#!/usr/bin/env python3
import json
import subprocess
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

class MultiServiceHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # http.server 默认使用 latin-1 解码 url。我们需要还原为字节流并用 utf-8 正确解码，以支持中文
        raw_path = self.path.encode('latin-1')
        decoded_path = urllib.parse.unquote_to_bytes(raw_path).decode('utf-8', errors='replace')

        parsed_url = urllib.parse.urlparse(decoded_path)
        path = parsed_url.path
        query_params = urllib.parse.parse_qs(parsed_url.query)

        # 路由分发 (只处理 /say_server，其他路由返回 404，为以后扩展做准备)
        if path == '/say_server':
            self.handle_say(query_params)
        else:
            self.handle_not_found(path)

    def handle_say(self, params):
        text = params.get('text', [''])[0]
        voice = params.get('voice', ['Lili'])[0]  # 默认使用 macOS 更自然的中文女声 Lili (如 Lili, Siri, Yuting, Tingting 等)

        if not text:
            self.send_json_response(400, {
                "status": "error",
                "message": "Missing 'text' parameter. Usage: /say?text=内容"
            })
            return

        try:
            # 异步调用 Mac 的 say 命令，避免播放长文本时阻塞 HTTP 响应
            subprocess.Popen(['say', '-v', voice, text])
            self.send_json_response(200, {
                "status": "success",
                "message": f"Successfully playing text: '{text}' using voice '{voice}'"
            })
        except Exception as e:
            self.send_json_response(500, {
                "status": "error",
                "message": f"Failed to execute say command: {str(e)}"
            })

    def handle_not_found(self, path):
        # 404 路由处理，便于后续在 12345 端口扩展其他路由
        self.send_json_response(404, {
            "status": "error",
            "message": f"Route '{path}' not found on this server. Did you mean /say_server?"
        })

    def send_json_response(self, status_code, data):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        # 允许跨域请求 (CORS)，方便其他网页或智能家居设备直接调用
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response_bytes = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.wfile.write(response_bytes)

if __name__ == '__main__':
    PORT = 12345
    server = HTTPServer(('0.0.0.0', PORT), MultiServiceHandler)
    print(f"HTTP Server started on port {PORT}. Accessible within LAN.")
    print(f"Speech Endpoint: http://<MAC_SAY_BACKUP_IP>:{PORT}/say_server?text=hello")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server.")
